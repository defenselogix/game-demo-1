// Placeholder for game constants
export var GAME_SPEED = 1;
